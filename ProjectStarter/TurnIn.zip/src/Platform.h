#include <SDL2/SDL.h>
#include <iostream>
#include <stdio.h>
#include <vector>

class Platform {

    //width and height of rectangle
    int height;
    int width;
    
    //x and y positions on screen
    int x;
    int y;
    
};
