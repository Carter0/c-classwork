#include "GameLogic.h"

int main()
{
  GameLogic g;

  g.run();

  return 0;
}
